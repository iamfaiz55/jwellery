import React from 'react'

const RecentDeleteProduct = () => {
    return (
        <div>RecentDeleteProduct</div>
    )
}

export default RecentDeleteProduct